export class FluentBusinesses {
    data;
    constructor(data) {
        this.data = data;
    }
    getData() {
        return this.data;
    }
    fromCityInState(city, state) {
        return new FluentBusinesses(this.data.filter(a => a.city === city && a.state === state));
    }
    hasStarsGeq(stars) {
        // TODO
        return new FluentBusinesses(this.data.filter(a => a.stars !== undefined && a.stars >= stars));
    }
    inCategory(category) {
        // TODO
        return new FluentBusinesses(this.data.filter(a => a.categories !== undefined && a.categories.includes(category)));
    }
    hasHoursOnDays(days) {
        // TODO
        return new FluentBusinesses(this.data.filter(a => days.every(c => a.hours !== undefined && Object.keys(a.hours).includes(c))));
    }
    hasAmbience(ambience) {
        // TODO
        return new FluentBusinesses(this.data.filter(a => {
            if (a.attributes === undefined)
                return false;
            if (a.attributes.Ambience &&
                Object.keys(a.attributes.Ambience).includes(ambience) &&
                a.attributes.Ambience[ambience])
                return true;
            return false;
        }));
    }
    bestWhatever(choice) {
        const tieStarMax = this.getMaxValue("stars");
        const tieReviewMax = this.getMaxValue("review_count");
        const maxStarBusiness = this.getMaxBusiness("stars", tieStarMax);
        const mostReviewOfMostStar = this.getMostReviewORStar(maxStarBusiness, "review_count");
        const maxReviewBusiness = this.getMaxBusiness("review_count", tieReviewMax);
        const mostStarOfMostReview = this.getMostReviewORStar(maxReviewBusiness, "stars");
        if (choice === "bestPlace") {
            return maxStarBusiness.find(x => x.review_count === mostReviewOfMostStar);
        }
        else if (choice === "mostReviews") {
            return maxReviewBusiness.find(x => x.stars === mostStarOfMostReview);
        }
        return undefined;
    }
    getMaxValue(property) {
        return this.data.reduce((acc, e) => {
            if (e[property] !== undefined && e[property] >= acc) {
                acc = e[property];
            }
            return acc;
        }, Number.MIN_VALUE);
    }
    getMaxBusiness(property, maxValue) {
        return this.data.filter(a => a[property] === maxValue && a[property] !== undefined);
    }
    getMostReviewORStar(businesses, property) {
        return businesses.reduce((acc, e) => {
            if (e[property] !== undefined && e[property] >= acc) {
                acc = e[property];
            }
            return acc;
        }, Number.MIN_VALUE);
    }
    bestPlace() {
        // TODO
        return this.bestWhatever("bestPlace");
    }
    mostReviews() {
        // TODO
        return this.bestWhatever("mostReviews");
    }
}
//# sourceMappingURL=FluentBusinesses.js.map